<?php
date_default_timezone_set('Asia/Kuala_Lumpur');
$server = "localhost";
$user = "root";
$pwd = "";
$db = "rent";
mysql_connect($server,$user,$pwd) or die("If you seen any error in database, please call Administrator :)");
mysql_select_db($db);

function semak_admin(){
 if($_SESSION['user']==""){
  header("Location:index.php");
 }
}
?>
