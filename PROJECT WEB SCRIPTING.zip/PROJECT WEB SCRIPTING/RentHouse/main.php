<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rent House For Student</title>
</head>
<style>

body {
	background-image: url("img12.jpg");
    background-color: #cccccc;
	 
}

#header {
	height: 98px;
	margin-right: auto;
	margin-left: 0px;
	position: absolute;
	margin-top: 0px;
	border: none;
	font-family: Calibri;
	color: #000;
	left: 0px;
	top: 0px;
	background-color: rgba(0,0,0,0.7);
	right: 0px;
	z-index: 4;
}

#center {
	position: relative;
    left: -100px;
	top: 150px;
    
	
}

#myDIV:hover {
    position: absolute;
    width: 100px;
    height: 100px;
    background-color: white;
    color: white;
}

#main {
	position: absolute;
    left: 100px;
    top: 250px;
}



#mainn {
	position: absolute;
    left: 700px;
    top: 250px;
}



#foot {
	position: absolute;
	left: 0px;
	top: 1000px;
	height: 174px;
	z-index: 1001;
	right: 0px;
	background-color: rgba(0,0,0,0.9);
	padding: 30px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	color: rgba(255,255,255,1);
}
</style>



<body>


  <div id="header">
    <a href="indexx.php"><H1> RENT HOUSE</H1></a>
  </div>
    
    
    
    <div id="center">
    <form id="form1" name="form1" method="POST" action="processAddCler.php" enctype="multipart/form-data" >
    <label for="fileToUpload">
    <center><img src="PicImage.jpg" align="middle" style="cursor:pointer" onmouseover="this.src='PicImage.jpg'" onmouseout="this.src='PicImage.jpg'" alt="Upload" style="float:right;margin:7px" width="150" height="100" /></center>
</label>

    <input type="file" id="fileToUpload" name="fileToUpload" style="cursor: pointer;  display: none"/ required>
    <input type="submit" id="Up" style="display: none;" />

<script type="text/javascript">
    $( "#FileInput" ).change(function() {
      $( "#Up" ).click();
    });
	
	$("p").mouseover(function(){
    $("p").css("background-color", "black");
});
</script>

    
    </div>
    
    
 <div id="main">
 
 <h3>Add Detail</h3>
 
  			
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            Single Storey &nbsp: 
            <select id="Storey" class="Storey" name="Storey" form="form1">
                <option value="Single">Single</option>
                <option value="Double">Double</option>
              </select>
            
            
            <p>
            
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            
            
            Bathroom &nbsp&nbsp&nbsp :
            
              <select id="Bathroom" class="Bathroom" name="Bathroom" form="form1">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
          
            
            <p>
            
            
            
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            
            Bedroom &nbsp&nbsp&nbsp&nbsp :
            
              <select id="Bedroom" class="Bedroom" name="Bedroom" form="form1">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            
            
            <p>
            
            
            
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            
            Furniture &nbsp&nbsp&nbsp :
            
              <select id="Furniture" class="Furniture" name="Furniture" form="form1">
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
           
    



<!--
<h3>Other</h3>
			
     
			&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  <input type="checkbox" name="other" value="Aircond">&nbspAir-cond <br>
            
			&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  <input type="checkbox" name="other" value="Cooking">&nbspCooking Allowed <br>
            
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  <input type="checkbox" name="other" value="Washing">&nbspWashing Machine <br>
            
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  <input type="checkbox" name="other" value="Internet">&nbspInternet <br>

 -->
 <br><br>
<h3>Monthly Rent</h3>

			
			
            Price &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp : <input type="text" id="Rent" name="Rent" value="" required>
			
 
 
 
 
  <br><br><br><br>
  
<h3>Login </h3>
			
			Username &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <input type="text" id="Username" name="Username" value="" required>
            <br><p>
			Password &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <input type="text" id="Password" name="Password" value="" required>
            <br><br>
			
 
 
 
  </div>
 
			
			

 
 

 <div id="mainn">
 
 
<h3>Add Title</h3>

			
			
            Title &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            &nbsp&nbsp&nbsp : <input type="text" id="Title" name="Title" value="" required>
			
 
<br><br><br><br><br> 
  
<h3>Address</h3>

 	<textarea id="Address" form="form1" name="Address" rows="4" cols="50" required>

	</textarea>
 
 
 <br><br><br><br><br> 
 
<h3>Details</h3>
			
			Name &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <input type="text" id="Name" name="Name" value="" required>
            <br><p>
			Contact &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <input type="text" id="Contact" name="Contact" value="" required>
            <br><br>
            
            
			<input type="submit" value="Submit">
			</form>
 
<!-- <form action="myform.cgi">
<input type="file"  name="fileupload" value="fileupload" id="fileupload">
<label for="fileupload"> Select a file to upload</label>
<br>
<input type="image" src="/wp-content/uploads/sendform.png" alt="Submit" width="100">
</form>-->





</div>


 <div id="foot">

  <p><center>About Us  |  Rules  |  Post Free Ad  |  Shop Safely  |  Banner Advertising  |  Contact Us  |  Terms  |  Privacy  |  Watch Video Guide  </p>
  
</div>


</body>


</html>
