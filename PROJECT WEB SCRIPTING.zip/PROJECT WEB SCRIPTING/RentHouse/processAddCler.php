<?php
session_start();

//$cid = $_POST['cid'];
//$cpwd = $_POST['cpwd'];
//$cfname = $_POST['cfname'];
//$cic = $_POST['cic'];
//$cposition = $_POST['cposition'];
//$cphone = $_POST['cphone'];
//$cadd= $_POST['cadd'];
//$cemail = $_POST['cemail'];


	/*$fullname = $_POST['Name_Owner']; 
	$ic = $_POST['Ic_Number'];
	$phone = $_POST['Phone_Number'];  
	$ownadd= $_POST['Address_Owner'];
	$resname = $_POST['Rstrn_Name']; 
	$resphonenum = $_POST['Rstrn_PhoneNumber'];
	$reslicnum = $_POST['Rstrn_RegistrationNumber'];
	$resadd = $_POST['Rstrn_Address'];
	$username = $_POST['User_Name'];
	$password = $_POST['Password'];  
	$email=$_POST['Email'];*/
	
	$storey = $_POST['Storey']; 
	$bathroom = $_POST['Bathroom'];
	$bedroom = $_POST['Bedroom'];  
	$furniture= $_POST['Furniture'];
	$rent = $_POST['Rent'];
	$username = $_POST['Username']; 
	$password = $_POST['Password']; 
	$title = $_POST['Title'];
	$address = $_POST['Address'];
	$name = $_POST['Name'];
	$contact = $_POST['Contact'];
	



$q = "INSERT INTO seller".
		//" (sta_id,sta_pwd,sta_fname,sta_ic,sta_position,sta_phoneNumber,sta_address,sta_email,role_id)". 
	 	 " (id,storey,bathroom,bedroom,furniture,rent,title,address,name,contact,username,password)". 
		 " VALUES".
	 	// " ('{$cid}','{$cpwd}','{$cfname}','{$cic}','{$cposition}','{$cphone}','{$cadd}','{$cemail}','5')";
			"('','$storey','$bathroom','$bedroom','$furniture','$rent','$title','$address','$name','$contact','$username','$password')";
			
			
require_once("connect.inc.php");
mysqli_query($dbc,$q);

//$login= "INSERT INTO login".
	 	// " (username,password,role_id)". 
		// " VALUES".
	 	// " ('{$username}','{$password}','1')";

//mysqli_query($dbc,$login);
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

?>
<script language="javascript">
  alert("berjaya register");
  window.location="main.php";
 </script>
//<?php
//if(mysqli_affected_rows($dbc) > 0)
//{
//	
//	$fullname = $_POST['Name_Owner'];
//	header("Location:FormFill.php");
//	
//
//}
//
//mysqli_close($dbc);
//exit();
//?>

