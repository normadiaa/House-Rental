<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rent House For Student</title>
</head>
<style>

body {
	background-image: url("img12.jpg");
    background-color: #cccccc;
	 
}

#header {
	height: 98px;
	margin-right: auto;
	margin-left: 0px;
	position: absolute;
	margin-top: 0px;
	border: none;
	font-family: Calibri;
	color: #000;
	left: 0px;
	top: 0px;
	background-color: rgba(0,0,0,0.7);
	right: 0px;
	z-index: 4;
}

#option {
	position: absolute;
    left: 100px;
    top: 250px;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
} 

#foot {
	position: absolute;
	left: 0px;
	top: 1000px;
	height: 174px;
	z-index: 1001;
	right: 0px;
	background-color: rgba(0,0,0,0.9);
	padding: 30px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	color: rgba(255,255,255,1);
}

</style>

<body>

<div id="header">
    <H1> RENT HOUSE</H1>
  </div>
  
  
<div id="option">

<a href="edit.php"><button type="button" class="button" >EDIT YOUR PROFILE</button></a><br></br>
<button type="button" class="button" onclick="myFunction()">DELETE YOUR PROFILE</button><br></br>

 <li><a href="logout.php">Logout</a></li>
</div>

<div id="foot">

<p><center>About Us  |  Rules  |  Post Free Ad  |  Shop Safely  |  Banner Advertising  |  Contact Us  |  Terms  |  Privacy  |  Watch Video Guide  </p>

 

</div>

</body>
</html>

<script>
function myFunction() {
    var txt;
    var r = confirm("Are you sure you want to delete your profile?");
    if (r == true) {
        txt = "You pressed OK!";
        window.location="delete.php";

    } else {
        txt = "You pressed Cancel!";
        window.location="loginpage.php";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>