
<?php
error_reporting(0);
?>
<?php
session_start();
$host="localhost";
$susername="root";
$spassword="";
$db_name="rent";
$tbl_name="seller";

$username = $_SESSION['username'];
//$id=$_POST['id'];
//$NoPerolehan =$_POST['nama'];
//$TajukBuku =$_POST['TajukBuku'];
//$NamaPengarang =$_POST['NamaPengarang'];
//$Penerbit =$_POST['Penerbit'];
//$Tahun =$_POST['Tahun'];
//$NoSiri =$_POST['id'];
//$Lokasi =$_POST['Lokasi'];

	$storey = $_POST['storey']; 
	$bathroom = $_POST['bathroom'];
	$bedroom = $_POST['bedroom'];  
	$furniture= $_POST['furniture'];
	$rent = $_POST['rent'];
	$title = $_POST['title'];
	$address = $_POST['address'];
	$name = $_POST['name'];
	$contact = $_POST['contact'];
/*$notelefon =$_POST['notelefon'];
$alamat =$_POST['alamat'];
$nama_rest =$_POST['nama_rest'];
$notel_rest =$_POST['notel_rest'];
$lesen_rest =$_POST['lesen_rest'];
$alamat_rest = $_POST['alamat_rest'];
$email =$_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
//$username_pemilik = $_POST['username_pemilik'];
//$password_pemilik = $_POST['password_pemilik'];
$status = $_POST['status'];

$catatan = $_POST['catatan'];*/

//connect to server and database
mysql_connect("$host", "$susername", "$spassword") or die ("cannot select DB");
mysql_select_db("$db_name") or die ("cannot select Table");

$sql="UPDATE $tbl_name SET storey='$storey', bathroom='$bathroom', bedroom='$bedroom', furniture='$furniture', rent='$rent', title='$title', address='$address', name='$name', contact='$contact' WHERE username = '$username'";
//, notelefon='$notelefon', alamat='$alamat', nama_rest='$nama_rest', notel_rest='$notel_rest', lesen_rest='$lesen_rest', alamat_rest='$alamat_rest', email='$email', username='$username', password='$password', status='$status', catatan='$catatan' WHERE nama='$nama'";

$result=mysql_query($sql);
mysql_query($query);

//if successful updated.

if($result){?>
	<script language="javascript">
  alert("berjaya update profile");
  window.location="loginpage.php";
 </script>
 <?php
	echo "Successful";
	echo "<BR>";
	echo "<a href='loginpage.php'> View result</a>";
}

else{
	echo "ERROR";
}
?>
