<?php
session_start();
include "connect.inc.php";
$username = $_SESSION['username'];
$sql = "SELECT * FROM seller WHERE username='$username'";
$result = mysql_query($sql);

while($rs=mysql_fetch_array($result)){

 $storey = $rs['storey'];
 $bathroom = $rs['bathroom'];
 $bedroom = $rs['bedroom'];
 $furniture = $rs['furniture'];
 $rent = $rs['rent'];
 $title = $rs['title'];
 $address = $rs['address'];
 $name = $rs['name'];
 $contact = $rs['contact'];
 
 
 
}
?>
<div id="borang">
<form name="frm" method="post" action="edit_proses.php" onsubmit="return semak()">
<table align="center">

<tr><tr><td><h3>Owner Details</h3></td></tr>



<tr>
 <td class="kanan">storey</td>
 <td><input type="text" name="storey" style="width:300px;" value="<?php echo $storey;?>"></td>
</tr> 
<tr>
 <td class="kanan">bathroom</td>
 <td><input type="text" name="bathroom" style="width:300px;" value="<?php echo $bathroom;?>"></td>
</tr>
<tr>
 <td class="kanan">bedroom</td>
 <td><input type="text" name="bedroom" style="width:300px;" value="<?php echo $bedroom;?>"></td>
</tr> 
<tr>
 <td class="kanan">furniture</td>
 <td><input type="text" name="furniture" style="width:300px;" value="<?php echo $furniture;?>"></td>
</tr>
<tr>
 <td class="kanan">rent</td>
 <td><input type="text" name="rent" style="width:300px;" value="<?php echo $rent;?>"></td>
</tr> 
<tr>
 <td class="kanan">title</td>
 <td><input type="text" name="title" style="width:300px;" value="<?php echo $title;?>"></td>
</tr>
<tr> 
 <td class="kanan" valign="top">address </td>
 <td><textarea name="address" cols="30" rows="5"><?php echo $address;?></textarea></td>
</tr>
<tr>
 <td class="kanan">name</td>
 <td><input type="text" name="name" style="width:300px;" value="<?php echo $name;?>"></td>
</tr>
<tr>
 <td class="kanan">contact</td>
 <td><input type="text" name="contact" style="width:300px;" value="<?php echo $contact;?>"></td>
</tr> 

<!--<tr>
 <td class="kanan">Phone Number</td>
 <td><input type="text" name="notelefon" value="<?php// echo $notelefon;?>"></td>
</tr>
<tr> 
 <td class="kanan">Email Address</td>
 <td><input type="text" name="email" style="width:200px;" value="<?php// echo $email;?>"></td>
</tr>
<tr> 
 <td class="kanan" valign="top">Address</td>
 <td><textarea name="alamat" cols="30" rows="5"><?php// echo $alamat;?></textarea></td>
</tr>


<tr><tr><td><h3>Restaurant Details</h3></td></tr>


<tr> 
 <td class="kanan">Restaurant Name</td>
 <td><input type="text" name="name" style="width:200px;" value="<?php// echo $name;?>"></td>
</tr>


<tr>
 <td class="kanan">Restaurant Phone Number</td>
 <td><input type="text" name="notel_rest" value="<?php// echo $notel_rest;?>"></td>
</tr>


<tr> 
 <td class="kanan">Restaurant License Number</td>
 <td><input type="text" name="lesen_rest" style="width:200px;" value="<?php// echo $lesen_rest;?>"></td>
</tr>

<tr> 
 <td class="kanan" valign="top">Restaurant Address</td>
 <td><textarea name="alamat_rest" cols="30" rows="5"><?php// echo $alamat_rest;?></textarea></td>
</tr>


<tr><tr><td><h3>Account Details</h3></td></tr>


<tr> 
 <td class="kanan">Username</td>
 <td><input type="text" name="username" style="width:200px;" value="<?php// echo $username;?>"></td>
</tr>

<tr> 
 <td class="kanan">Password</td>
 <td><input type="text" name="password" style="width:200px;" value="<?php//echo $password;?>"></td>
</tr>



<tr><tr><td><h3>Others Details</h3></td></tr>



<tr>
 <td class="kanan">Status</td>
 <td><input type="radio" name="status" value="Y" <?php// if ($status=="Y") echo "checked";?>> Ada <input type="radio" name="status" value="N" <?php// if ($status=="N") echo "checked";?>> Tiada</td>
</tr>
<tr> 
 <td class="kanan" valign="top">Notes</td>
 <td><textarea name="catatan" cols="30" rows="5"><?php// echo $catatan;?></textarea></td>
</tr>

-->

<tr> 
 <td class="kanan">&nbsp;</td>
 <td>
<br><input type="submit" value="Save" class="btn_simpan">
</td>
</tr>
</table> 
</form>
<li><a href="logout.php">Logout</a></li>

<script language="javascript">
function semak(){
 var lulus = "Y";
 lulus = tukar_warna(document.frm.no_id,lulus);
 lulus = tukar_warna(document.frm.nama,lulus);
 lulus = tukar_warna(document.frm.notel,lulus);
 
 if (lulus == "Y"){
  return true;
 }
 else{
  alert ("Input berwarna kuning wajib diisi!");
  return false;
 }
}

function tukar_warna(val,status){
 if (val.value == ""){
  val.style.background = "yellow";
  return "N"; 
 }
 else{
  val.style.background = "white";
  return status;
 } 
}

function huruf_besar(val){
 val.value = val.value.toUpperCase();
}
</script>
