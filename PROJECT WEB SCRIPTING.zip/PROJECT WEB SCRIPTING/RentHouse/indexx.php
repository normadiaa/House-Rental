
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rent House For Student</title>
</head>

<style>

body {
	background-image: url("img12.jpg");
    background-color: #cccccc;
	 
}

#header {
	height: 98px;
	margin-right: auto;
	margin-left: 0px;
	position: absolute;
	margin-top: 0px;
	border: none;
	font-family: Calibri;
	color: #000;
	left: 0px;
	top: 0px;
	background-color: rgba(0,0,0,0.7);
	right: 0px;
	z-index: 4;
}

#option {
	position: absolute;
    left: 100px;
    top: 250px;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
} 

#foot {
	position: absolute;
	left: 0px;
	top: 1000px;
	height: 174px;
	z-index: 1001;
	right: 0px;
	background-color: rgba(0,0,0,0.9);
	padding: 30px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	color: rgba(255,255,255,1);
}

</style>

<body>


<div id="header">
    <a href="indexx.php"><H1> RENT HOUSE</H1></a>
  </div>
  
  
<div id="option">

<a href="searchh.php"><button type="button" class="button" >FIND</button></a><br></br>
<a href="option.php"><button type="button" class="button">SELLER</button></a><br></br>

 
</div>

<div id="foot">

<p><center>About Us  |  Rules  |  Post Free Ad  |  Shop Safely  |  Banner Advertising  |  Contact Us  |  Terms  |  Privacy  |  Watch Video Guide  </p>

 <form method="post" action="login_proses_admin.php">
  <p><input type="text" name="username" size="40" class="contactform"  placeholder="Username" required>
  </p>
  	
  <p> 
    <input type="password" name="password" size="40" class="contactform" placeholder="Password" required>
  </p>
  <p>
    <input type="submit" value="login" class="btn_login" size="40" id="SearchButton" required
    onmouseover="this.style.backgroundColor='#58C475';this.style.color='#fff';"
			onmouseout="this.style.backgroundColor='#fff';this.style.color='#58C475';"	
    
    >
  </p>
</form>

</div>

</body>
</html>