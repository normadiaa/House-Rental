
<!DOCTYPE html>
<html>
<head>
<title>Rent House For Student</title>
<style>
body {
	background-image: url("img12.jpg");
    background-color: #cccccc;
	 
}

#header {
	height: 98px;
	margin-right: auto;
	margin-left: 0px;
	position: absolute;
	margin-top: 0px;
	border: none;
	font-family: Calibri;
	color: #000;
	left: 0px;
	top: 0px;
	background-color: rgba(0,0,0,0.7);
	right: 0px;
	z-index: 4;
}

#foot {
	position: absolute;
	left: 0px;
	top: 1000px;
	height: 174px;
	z-index: 1001;
	right: 0px;
	background-color: rgba(0,0,0,0.9);
	padding: 30px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	color: rgba(255,255,255,1);
}




@import "compass/css3";

/***********************
 * Essential Structure *
 ***********************/
.flexsearch--wrapper {
	height: auto;
	width: auto;
	max-width: 100%;
	overflow: hidden;
	background: transparent;
	margin: 0;
	position: static;
}
	
.flexsearch--form {
	overflow: hidden;
	position: relative;
}
	
.flexsearch--input-wrapper {
	padding: 0 66px 0 0; /* Right padding for submit button width */
	overflow: hidden;
}

.flexsearch--input {
  width: 100%;
}

/***********************
 * Configurable Styles *
 ***********************/
.flexsearch {
  padding: 0 25px 0 200px; /* Padding for other horizontal elements */
	align-items: center;
}

.flexsearch--input {
  -webkit-box-sizing: content-box;
	-moz-box-sizing: content-box;
	box-sizing: content-box;
 	height: 60px;
  padding: 0 46px 0 10px;
	border-color: #888;
  border-radius: 35px; /* (height/2) + border-width */
  border-style: solid;
	border-width: 5px;
  margin-top: 15px;
  color: #333;
  font-family: 'Helvetica', sans-serif;
	font-size: 26px;
	-webkit-appearance: none;
	-moz-appearance: none;
}
	
.flexsearch--submit {
  position: absolute;
	right: 0;
	top: 0;
	display: block;
	width: 60px;
	height: 60px;
  padding: 0;
  border: none;
	margin-top: 20px; /* margin-top + border-width */
  margin-right: 5px; /* border-width */
	background: transparent;
  color: #888;
  font-family: 'Helvetica', sans-serif;
  font-size: 40px;
  line-height: 60px;
}

.flexsearch--input:focus {
  outline: none;
  border-color: #333;
}

.flexsearch--input:focus.flexsearch--submit {
 	color: #333; 
}

.flexsearch--submit:hover {
  color: #333;
  cursor: pointer;
}

::-webkit-input-placeholder {
	color: #888;  
}

input:-moz-placeholder {
  color: #888
}


/****************
 * Pretify demo *
 ****************/
.h1 {
  float: left;
  margin: 25px;
  color: #333;
  font-family: 'Helvetica', sans-serif;
  font-size: 45px;
  font-weight: bold;
  line-height: 45px;
  text-align: center;
}
</style>
</head>
<body>


<div id="header">
    <a href="indexx.php"><H1> RENT HOUSE</H1></a>
  </div>



<div id="search">
<br><br><br><br><br>

	<h1 class="h1">Address</h1>

<div class="flexsearch">
		<div class="flexsearch--wrapper">
			<form class="flexsearch--form" action="searchresult.php" method="GET">
				<div class="flexsearch--input-wrapper">
					<input class="flexsearch--input"  list="location" name="q" placeholder="search">
				</div>
				<input class="flexsearch--submit" type="submit" name="submit" id="submit" value="&#10140;"/>
			</form>
		</div>
</div>
	
</div>



<div id="foot">

<p><center>About Us  |  Rules  |  Post Free Ad  |  Shop Safely  |  Banner Advertising  |  Contact Us  |  Terms  |  Privacy  |  Watch Video Guide  </p>

</div>


</body>
</html>
