<?php

$host="localhost";
$username1="root";
$password1="";
$db_name="rent";


$con = mysqli_connect("$host","$username1","$password1")or die
("Hello Neo...I know why you have been searching.....but we cannot connect..");
mysqli_select_db($con,"$db_name") or die
("Hello neo...fllow the white rabbit...");
?>

