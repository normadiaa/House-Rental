<!DOCTYPE html>
<html>
<head>
<title>Rent House For Student</title>
<style>
body {
	background-image: url("img12.jpg");
    background-color: #cccccc;
	 
}

#header {
	height: 98px;
	margin-right: auto;
	margin-left: 0px;
	position: absolute;
	margin-top: 0px;
	border: none;
	font-family: Calibri;
	color: #000;
	left: 0px;
	top: 0px;
	background-color: rgba(0,0,0,0.7);
	right: 0px;
	z-index: 4;
}

#container {
	height: 100px;
	width: 1245px;
	margin-right: auto;
	margin-left: auto;
	position: absolute;
	margin-top: 0px;
	border: 1px solid rgba(0,0,0,1);
	font-family: verdana;
	color: #000;
	left: 30px;
	top: 371px;
	margin-bottom: 0px;
	background-color: rgba(0,0,0,0.0)
}

#foot {
	position: absolute;
	left: 0px;
	top: 1000px;
	height: 174px;
	z-index: 1001;
	right: 0px;
	background-color: rgba(0,0,0,0.9);
	padding: 30px;
	font-family: Verdana, Geneva, sans-serif;
	font-size: 14px;
	color: rgba(255,255,255,1);
}

@import "compass/css3";

/***********************
 * Essential Structure *
 ***********************/
.flexsearch--wrapper {
	height: auto;
	width: auto;
	max-width: 100%;
	overflow: hidden;
	background: transparent;
	margin: 0;
	position: static;
}
	
.flexsearch--form {
	overflow: hidden;
	position: relative;
}
	
.flexsearch--input-wrapper {
	padding: 0 66px 0 0; /* Right padding for submit button width */
	overflow: hidden;
}

.flexsearch--input {
  width: 100%;
}

/***********************
 * Configurable Styles *
 ***********************/
.flexsearch {
  padding: 0 25px 0 200px; /* Padding for other horizontal elements */
  align-items: center;
}

.flexsearch--input {
  -webkit-box-sizing: content-box;
	-moz-box-sizing: content-box;
	box-sizing: content-box;
 	height: 60px;
  padding: 0 46px 0 10px;
	border-color: #888;
  border-radius: 35px; /* (height/2) + border-width */
  border-style: solid;
	border-width: 5px;
  margin-top: 15px;
  color: #333;
  font-family: 'Helvetica', sans-serif;
	font-size: 26px;
	-webkit-appearance: none;
	-moz-appearance: none;
	align-items: center;
}
	
.flexsearch--submit {
  position: absolute;
	right: 0;
	top: 0;
	display: block;
	width: 60px;
	height: 60px;
  padding: 0;
  border: none;
	margin-top: 20px; /* margin-top + border-width */
  margin-right: 5px; /* border-width */
	background: transparent;
  color: #888;
  font-family: 'Helvetica', sans-serif;
  font-size: 40px;
  line-height: 60px;
}

.flexsearch--input:focus {
  outline: none;
  border-color: #333;
}

.flexsearch--input:focus.flexsearch--submit {
 	color: #333; 
}

.flexsearch--submit:hover {
  color: #333;
  cursor: pointer;
}

::-webkit-input-placeholder {
	color: #888;  
}

input:-moz-placeholder {
  color: #888
}


/****************
 * Pretify demo *
 ****************/
.h1 {
  float: left;
  margin: 25px;
  color: #333;
  font-family: 'Helvetica', sans-serif;
  font-size: 45px;
  font-weight: bold;
  line-height: 45px;
  text-align: center;
}
</style>
</head>
<body>

<div id="header">
    <a href="indexx.php"><H1> RENT HOUSE</H1></a>
  </div>




<div id="container">  


<h1 class="h1">Address</h1>
<div class="flexsearch">
		<div class="flexsearch--wrapper">
			<form class="flexsearch--form" action="searchresult.php" method="GET">
				<div class="flexsearch--input-wrapper">
					<input class="flexsearch--input" type="search" list="location" name="q" placeholder="search">
				</div>
				<input class="flexsearch--submit" type="submit" name="submit" id="submit" value="&#10140;"/>
			</form>
		</div>
</div>

<?php 
error_reporting(0);
session_start(); ?>


  <div class="navbar navbar-inverse" role="navigation">  
    
        <div class="templatemo-content-wrapper">
   		<div class="templatemo-content">
		<?php
		
		session_start();
		error_reporting(0);
  		// Get the search variable from URL

  		$var = @$_GET['q'] ;
  		$trimmed = trim($var); //trim whitespace from the stored variable

		// rows to return
		$limit=10; 

		// check for an empty string and display a message
		
		if ($trimmed == "")
 		 {
 		 	
 			 header("Location:search.php?reason=nosearch");
  		exit;
  		}
		 if (!isset($var))
  		{
  			
  			header("Location:search.php?reason=noisset");
  			exit;
 		 }
  
 		 //mysql_connect("localhost","root","");
 		 //mysql_select_db("medicalcentre") or die("Unable to select database");
			require_once 'fungsi.php';
  			$query = "select * from seller where name like \"%$trimmed%\" || address like \"%$trimmed%\" || title like \"%$trimmed%\"
  					  order by name"; 
 
  			$numresults=mysql_query($query);
 		    $numrows=mysql_num_rows($numresults);
 		    

			if ($numrows == 0)
   			 { 
   			 	 
				header("Location:index.php?reason=noresult");
  			 }

			// next determine if s has been passed to script, if not use 0
  			if (empty($s)) 
  			{
 			  $s=0;
 			 }

			// get results
  	   		 $query .= " limit $s,$limit";
 			 $result = mysql_query($query) or die("Couldn't execute query");
  
  			 print "<center>";
  			 print "<p></p>";
   			 echo "<p>You searched for: &quot;" . $var . "&quot;</p>";
   
   			 echo "Results";
   			 print "<br/><br/>";
  			 print "</center>";
  			 $count = 1 + $s ;

 			  print "<td><table id='datatable' class='table table-hover' width='1170' height='51' 
					align='center' cellpadding='10' cellspacing='0'>";
 			  print "</tr>";
  		
			
			  print "<tr>";
   			  print "<td bgcolor=#E6E6E6><center>House Name</center></td>";
   			  print "<td bgcolor=#E6E6E6><center>Address</center></td>";
  			  print "<td bgcolor=#E6E6E6><center>Price</center></td>";
  			  print "<td bgcolor=#E6E6E6><center>Storey</center></td>";
   			  print "<td bgcolor=#E6E6E6><center>Furniture </center></td>";
			  print "<td bgcolor=#E6E6E6><center>Bedroom</center></td>";
			  print "<td bgcolor=#E6E6E6><center>Bathroom</center></td>";
			  print "<td bgcolor=#E6E6E6><center>Name Owner</center></td>";
			  print "<td bgcolor=#E6E6E6><center>Contact</center></td>";
        	  print "</tr>";
			
   			
			 while ($row= mysql_fetch_array($result)) {
   			 $title = $row["title"];
   			 $address = $row["address"];
   			 $rent = $row["rent"];
   			 $storey = $row["storey"];
			 $furniture = $row["furniture"];
			 $bathroom = $row["bathroom"];
			 $bedroom = $row["bedroom"];
			 $name = $row["name"];
			 $contact = $row["contact"];

  
   			 print "<tr>";
			 print "<td><center>$title.</td>";
			 print "<td><center>$address</td>";
			 print "<td><center>$rent</td>";
			 print "<td><center>$storey</td>";
			 print "<td><center>$furniture</td>";
			 print "<td><center>$bathroom</td>";
			 print "<td><center>$bedroom</td>";
			 print "<td><center>$name</td>";
			 print "<td><center>$contact</td>";
			
			 print "</tr>";

			 $count++ ;
  			}
   			 print "</table>";

  			 $currPage = (($s/$limit) + 1);
  			 echo "<br />";

 			 // next we need to do the links to other results
  			 if ($s>=1) { // bypass PREV link if s is 0
  			 $prevs=($s-$limit);
  			 print "&nbsp;<center><a href=\"index.php?s=$prevs&q=$var\">&lt;&lt; 
  			 Prev 10</a>&nbsp&nbsp;";
  			}
			// calculate number of pages needing links
  			$pages=intval($numrows/$limit);
			// $pages now contains int of pages needed unless there is a remainder from division
  			if ($numrows%$limit) {
 			 // has remainder so add one page
 			 $pages++;
 			 }
			 // check to see if last page

		     if (!((($s+$limit)/$limit)==$pages) && $pages!=1) {
  			// not last page so give NEXT link
  			$news=(($s+$limit)/$limit);
			
 			 echo "&nbsp;<center><a href=\"index.php?s=$news&q=$var\">Next 10 &gt;&gt;</a>";
 			 }
			 $a = $s + ($limit) ;
  			 if ($a > $numrows) { $a = $numrows ; }
             $b = $s + 1 ;
  			 echo "<h6><p><center>Showing results $b to $a of $numrows</center></p></h6>";
  			 echo "<h6><center><a href='searchh.php'>Search again</a></center></h6>";
			?>
 </div>
 </div>
</div>
</div>


<div id="foot">

<p><center>About Us  |  Rules  |  Post Free Ad  |  Shop Safely  |  Banner Advertising  |  Contact Us  |  Terms  |  Privacy  |  Watch Video Guide  </p>

</div>

</body>
</html>
