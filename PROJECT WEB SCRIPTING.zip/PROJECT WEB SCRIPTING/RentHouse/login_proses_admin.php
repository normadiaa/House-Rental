<?php

  session_start();
  $username =  $_POST['username'];
  $password  = $_POST['password'];
  //$selectuser = $_POST['selectuser'];
   
  
//if ($selectuser=='admin')
//{
  if(!empty($username) && !empty($password))
  {
		//echo $username;die;
       include("db.php");
	    mysqli_real_escape_string($con,$username);
	   $query  = mysqli_query($con,"SELECT * FROM seller WHERE username ='$username'");
			//$sql ="SELECT * FROM $tbl_name1 WHERE username ='$username'";
			//echo $sql;die;echo $query;die;
			$numrows = mysqli_num_rows($query);
			 if ($numrows!=0)
			 {
				while($row= mysqli_fetch_assoc($query))
				{
					$dbusername = $row['username'];
					$dbpassword = $row['password'];
				
				}
			 //check to see if they match
				
				if ($username==$dbusername && $password==$dbpassword)
				{					
					echo "<script type='text/javascript'> alert('Welcome Admin . Your Login sucessfully . ')</script> ";
					echo "<script type='text/javascript'>window.location='loginpage.php'</script>";
					
					$_SESSION['username'] = $username ;
					$_SESSION['password'] = $password ;
						
				}
				else {
					//echo "Incorrect Password";
					echo "<script type='text/javascript'> alert('Incorrect Password. Please Try Again !!. ')</script> ";
					echo "<script type='text/javascript'>window.location='login.php'</script>";}
			 
			 }
			 else {
				echo "<script type='text/javascript'> alert('Incorrect User. Please Try Again !!.  ')</script> ";
				echo "<script type='text/javascript'>window.location='login.php'</script>";}
				
			 
  }
  else
  {
  die("Please enter your username and a password");
  }
   //}
   
  /* else if($selectuser=='user')
   {
		if($username && $password)
		{
			
			include ("db.php");
			$query  = mysqli_query($con,"SELECT * FROM id_user WHERE username = '$username' ");
			
			$numrows = mysqli_num_rows($query);
			 if ($numrows!=0)
			 {
			 
				while($row= mysqli_fetch_assoc($query))
				{
					$dbusername = $row['username'];
					$dbpassword = $row['password'];				
					$user_id 	= $row['user_id'];				
				}
			 //check to see if they match

				if ($username==$dbusername && $password==$dbpassword)
				{
				
					echo "<script type='text/javascript'> alert('Welcome  . Your Login sucessfully . ')</script> ";
					echo "<script type='text/javascript'>window.location='user_page.php'</script>";
				
					$_SESSION['username'] = $username;	
					$_SESSION['user_id'] = $user_id;	
				}
				else
					//echo "Incorrect Password";
					echo "<script type='text/javascript'> alert('Incorrect Password. Please Try Again !!.  ')</script> ";
					echo "<script type='text/javascript'>window.location='login.php'</script>";
			 
			 }
			 else
				echo "<script type='text/javascript'> alert('Incorrect User. Please Try Again !!.  ')</script> ";
					echo "<script type='text/javascript'>window.location='login.php'</script>";
			 
  
		}
  else
  die("Please enter a username and a password");
   
   }*/

 
?>